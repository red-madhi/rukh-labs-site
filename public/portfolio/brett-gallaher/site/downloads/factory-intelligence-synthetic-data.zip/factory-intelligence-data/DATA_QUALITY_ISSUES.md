# Data-quality issues

The defects below are deliberate and deterministic. They are test fixtures, not accidental corruption.

| Defect | Injected | Handling |
|---|---:|---|
| Historian duplicate revisions | 24 | Keep latest `loaded_at_utc` per record ID |
| Historian missing good units | 30 | Reject from FactProduction |
| Historian dirty facility codes | 12 | Trim and uppercase |
| Historian adjustment records | 18 | Exclude non-production record type |
| CMMS orphan asset references | 5 | Reject with inner master join |
| QMS invalid dates | 6 | Reject failed date parse |
| QMS blank line identifiers | 9 | Reject missing business key |
| Inventory duplicate snapshots | 10 | Deduplicate by snapshot ID |
| Procurement dirty supplier codes | 15 | Trim and uppercase |
| Historian schema drift | Jan–Mar | Add missing energy column before type enforcement |

Expected rejected identifiers are retained in `data/rejected/expected-rejections.json`. The independent validator recovered every injected count and reconciled the production controls.

