# Source systems

| Source | Format | Grain | Purpose | Expected rows |
|---|---|---|---|---:|
| Production Historian | Monthly CSV folder | Line-hour reading | Output, runtime, cycle, scrap, energy | 105,162 raw |
| Maintenance CMMS | SQLite plus portable CSV exports | Work-order revision / downtime event | Reliability and Pareto | 1,482 raw |
| Quality QMS | JSON Lines | Inspection event | Defect and disposition analysis | 22,000 |
| Inventory ERP | CSV | Material-facility-week snapshot | Days supply and what-if risk | 6,250 raw |
| Procurement | CSV | Purchase-order line | Delivery, quality, and PPV | 3,600 |
| Supplier Master | JSON | Supplier | Conformed supplier attributes | 12 |
| Labor Roster | CSV | Facility-shift team | Team/headcount dimension | 12 |
| Security Access | CSV | User-facility-shift grant | Dynamic RLS bridge | 8 |

The machine-readable contract is `data/config/source-manifest.json`. Each source is generated independently and joined only in Power Query/the semantic model. The portable CMMS CSV exports mirror the SQLite tables so Desktop refresh does not depend on an external SQLite connector.

