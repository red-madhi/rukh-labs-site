# Factory Intelligence System

Status: **Power BI Desktop semantic validation passed**

An original, fully synthetic manufacturing analytics case study built from eight independently generated source systems. The project proves ingestion, data-quality remediation, dimensional modeling, reusable DAX, dynamic RLS, date-windowed refresh design, PBIR authoring, and a web-native analytical demo from one governed set of control totals.

## Open locally

1. If using the downloaded ZIP, choose **Extract All** first. Open `FactoryIntelligence.pbip` from the extracted folder; do not open it while it remains inside the ZIP.
2. If working from this source checkout, run `scripts/generate-data.ps1` to rebuild the deterministic sources, then open `report/FactoryIntelligence.pbip`.
3. The local workspace copy is preconfigured to use `C:\FactoryIntelligenceData`, a neutral local copy of the bundled fixture data. If the project is moved to another computer, download the companion synthetic-data archive and set `pDataRoot` to its extracted `data` directory.
4. Refresh, test every RLS persona, and save.

Power BI Desktop 2.156.951.0 validated the source model on 2026-08-04: the PBIP opened, all twelve M-backed tables refreshed from the fixture data, the calculation group evaluated, and the reconciled DAX controls matched the expected baseline. This local copy defaults to a neutral Public Documents fixture location. If moved or shared, reset `pDataRoot` to the extracted project's `data` folder. Visual-rendering, mobile-layout, and fictional-persona impersonation still need an interactive Desktop review.

## Reconciled baseline

- Clean production rows: 105,090
- Scheduled minutes: 6,305,400
- Run minutes: 5,960,657.675
- Good / total units: 6,911,085 / 7,128,472
- OEE: 82.3296%
- Scrap rate: 3.0496%
- Deterministic content hash: `53ac95775cca34733b647c702af24e1025844fdccfd1c0facedd37a6b84b4bbd`

All organizations, people, users, operations, and performance results are fictional. No employer, client, or confidential data is used.
