# Data dictionary

## Facts

| Table | Grain | Primary metrics | Conformed keys |
|---|---|---|---|
| FactProduction | One valid, latest line-hour record | scheduled/run minutes, units, energy | date, facility, line, team |
| FactDowntime | One valid downtime event | duration, planned flag | date, facility, line, asset |
| FactQuality | One valid inspection | inspected and defect units | date, facility, line, material |
| FactInventorySnapshot | One material-facility-week | on hand, open orders, demand, cost | date, facility, material |
| FactProcurement | One purchase-order line | ordered/received/defect units, price | order date, receipt date, supplier, facility, material |

## Dimensions and helpers

`DimDate`, `DimFacility`, `DimLine`, `DimAsset`, `DimMaterial`, `DimSupplier`, and `DimShift` provide descriptive attributes. `BridgeUserAccess` holds fictional UPN grants. `Metric Selector`, `Inventory Buffer Days`, and `Time Calculation` are intentionally disconnected analytical helpers. `_Measures` is the certified measure table.

Foreign-key columns are hidden. Labels remain visible. Dates use a marked, continuous calendar. `Order Date` is the active procurement date; `Received Date` is inactive for explicit receipt-date calculations.

