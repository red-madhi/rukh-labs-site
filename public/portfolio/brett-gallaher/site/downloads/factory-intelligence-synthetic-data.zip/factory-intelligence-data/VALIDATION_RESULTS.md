# Validation results

Status: **automated source validation and Power BI Desktop semantic validation passed**.

The generator produced 105,162 historian rows and the transformation contract yields 105,090 valid latest production rows. It recovered 24 duplicate revisions, 30 missing-good-unit rejects, 12 dirty facility codes, 18 adjustment records, 5 CMMS orphans, 6 invalid quality dates, 9 blank quality line keys, 10 inventory duplicates, and 15 dirty supplier codes.

Reconciled baseline: 6,305,400 scheduled minutes; 5,960,657.675 run minutes; 6,911,085 good units; 7,128,472 total units; 82.3296% OEE; 3.0496% scrap. Two consecutive generations produced identical business content hash `53ac95775cca34733b647c702af24e1025844fdccfd1c0facedd37a6b84b4bbd`.

On 2026-08-04, Power BI Desktop opened the PBIP and its local Analysis Services model loaded 17 tables, 46 measures, 20 relationships, one calculation group, and one dynamic RLS role. All twelve M-backed partitions refreshed from the fixture data through the local full-refresh path. DAX returned the reconciled controls: 105,090 FactProduction rows; 6,305,400 scheduled minutes; 5,960,657.675 run minutes; 6,911,085 good units; 7,128,472 total units; 217,387 scrap units; 82.3296% OEE; and 344,742.325 production-capacity downtime minutes. The time calculation group also returned valid MTD, YTD, and prior-month OEE results.

The RLS expression loaded and filtered an unmatched local Windows identity to no data. Desktop's local endpoint cannot impersonate the fictional `example.com` identities through `EffectiveUserName`, so persona-by-persona View-as-role evidence and report-layout rendering remain pending. No PBIX, PBIT, or screenshots were created.

Machine-readable evidence is in `docs/validation/factory-intelligence-data-validation.json` and `data/generated-manifests/generation-manifest.json`.
