from __future__ import annotations

import csv
import json
import math
import random
import shutil
import sqlite3
import sys
from collections import Counter, defaultdict
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = Path(__file__).resolve().parents[4]
DATA_ROOT = PROJECT_ROOT / "data"
CONFIG_PATH = DATA_ROOT / "config" / "generation-config.json"
sys.path.insert(0, str(REPO_ROOT / "data" / "shared-generator-utilities"))

from generation import round_metric, sha256_file, sha256_text, stable_json, write_csv, write_json  # noqa: E402


def reset_generated_directories() -> None:
    if PROJECT_ROOT.name != "03-factory-intelligence-system" or DATA_ROOT.name != "data":
        raise RuntimeError("Safety check failed: generator target is not the Factory Intelligence data directory.")
    for name in ["raw", "reference", "rejected", "expected-results", "web-aggregates", "generated-manifests"]:
        target = DATA_ROOT / name
        resolved = target.resolve()
        if DATA_ROOT.resolve() not in resolved.parents:
            raise RuntimeError(f"Refusing to clear unexpected path: {resolved}")
        if target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True, exist_ok=True)


def iso_hour(day: date, hour: int) -> str:
    return datetime(day.year, day.month, day.day, hour, tzinfo=UTC).isoformat().replace("+00:00", "Z")


def daterange(start: date, end: date):
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


def main() -> None:
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    rng = random.Random(config["seed"])
    config_hash = sha256_text(stable_json(config))
    start = date.fromisoformat(config["dateStart"])
    end = date.fromisoformat(config["dateEnd"])
    reset_generated_directories()

    facilities = config["facilities"]
    lines = []
    assets = []
    for facility in facilities:
        for line_number in range(1, config["linesPerFacility"] + 1):
            line_id = f"{facility['id']}-L{line_number:02d}"
            family = ["Stamping", "Assembly", "Finishing"][line_number - 1]
            ideal_cycle = [0.62, 0.78, 0.91][line_number - 1]
            lines.append({
                "line_id": line_id,
                "facility_id": facility["id"],
                "line_name": f"{family} {line_number}",
                "process_family": family,
                "ideal_cycle_minutes": ideal_cycle,
            })
            for asset_number in range(1, 5):
                assets.append({
                    "asset_id": f"{line_id}-A{asset_number:02d}",
                    "line_id": line_id,
                    "asset_type": ["Press", "Conveyor", "Robot", "Inspection Cell"][asset_number - 1],
                    "criticality": ["High", "Medium", "High", "Medium"][asset_number - 1],
                })

    materials = [
        {"material_id": f"MAT-{index:03d}", "material_name": f"Synthetic Material {index:03d}", "category": ["Metal", "Polymer", "Electronic", "Packaging"][index % 4]}
        for index in range(1, config["materials"] + 1)
    ]
    supplier_names = [
        "Atlas Motion", "BluePeak Components", "NovaCore Materials", "Summit Industrial",
        "Cedar Robotics", "Meridian Controls", "Northstar Packaging", "ArcLight Systems",
        "ForgeLine Supply", "Kestrel Precision", "Copperleaf Electronics", "Vector Automation",
    ]
    suppliers = [
        {
            "supplier_id": f"SUP-{index:03d}",
            "supplier_name": supplier_names[index - 1] if index <= len(supplier_names) else f"Partner {index:02d}",
            "country": ["US", "CA", "MX", "DE", "JP", "GB"][index % 6],
            "risk_band": ["Low", "Low", "Medium", "Medium", "High"][index % 5],
            "email_domain": "example.com",
        }
        for index in range(1, config["suppliers"] + 1)
    ]

    write_json(DATA_ROOT / "reference" / "facilities.json", facilities)
    write_csv(DATA_ROOT / "reference" / "lines.csv", lines, list(lines[0]))
    write_csv(DATA_ROOT / "reference" / "materials.csv", materials, list(materials[0]))
    write_json(DATA_ROOT / "raw" / "supplier-master" / "suppliers.json", suppliers)

    historian_rows: list[dict[str, Any]] = []
    base_rows: list[dict[str, Any]] = []
    record_number = 0
    facility_effect = {"F01": 0.00, "F02": -0.035, "F03": 0.025, "F04": -0.01}
    for day in daterange(start, end):
        season = 0.025 * math.sin((day.timetuple().tm_yday / 365) * math.tau)
        for hour in range(24):
            shift_id = "S1" if hour < 8 else "S2" if hour < 16 else "S3"
            for line in lines:
                record_number += 1
                facility_id = line["facility_id"]
                planned_loss = 5 if day.weekday() == 6 and hour in (2, 3) else 0
                unplanned_loss = max(0.0, rng.gauss(2.8 - facility_effect[facility_id] * 20, 3.2))
                run_minutes = max(2.0, 60.0 - planned_loss - unplanned_loss)
                target_units = run_minutes / line["ideal_cycle_minutes"]
                performance = min(1.08, max(0.68, rng.gauss(0.91 + facility_effect[facility_id] + season, 0.045)))
                total_units = max(1, int(target_units * performance))
                scrap_rate = min(0.16, max(0.004, rng.gauss(0.028 - facility_effect[facility_id] / 2, 0.013)))
                scrap_units = min(total_units, int(round(total_units * scrap_rate)))
                good_units = total_units - scrap_units
                record_id = f"PRD-{record_number:09d}"
                row = {
                    "record_id": record_id,
                    "timestamp_utc": iso_hour(day, hour),
                    "facility_id": facility_id,
                    "line_id": line["line_id"],
                    "shift_id": shift_id,
                    "scheduled_minutes": 60,
                    "run_minutes": round(run_minutes, 3),
                    "ideal_cycle_minutes": line["ideal_cycle_minutes"],
                    "total_units": total_units,
                    "good_units": good_units,
                    "scrap_units": scrap_units,
                    "energy_kwh": round(total_units * rng.uniform(0.55, 0.83), 3),
                    "record_type": "Production",
                    "loaded_at_utc": iso_hour(day + timedelta(days=1), 3),
                }
                base_rows.append(dict(row))
                historian_rows.append(row)

    production_indices = list(range(len(historian_rows)))
    for index in rng.sample(production_indices, config["historianMissingGoodUnits"]):
        historian_rows[index]["good_units"] = ""
    for index in rng.sample(production_indices, config["historianDirtyFacilityCodes"]):
        historian_rows[index]["facility_id"] = f" {historian_rows[index]['facility_id'].lower()} "
    duplicate_indices = rng.sample(production_indices, config["historianDuplicateRows"])
    historian_rows.extend(dict(historian_rows[index]) for index in duplicate_indices)
    for adjustment_number, index in enumerate(rng.sample(production_indices, config["historianAdjustments"]), start=1):
        original = historian_rows[index]
        historian_rows.append({
            **original,
            "record_id": f"ADJ-{adjustment_number:06d}",
            "total_units": -rng.randint(1, 8),
            "good_units": -rng.randint(1, 6),
            "scrap_units": 0,
            "record_type": "Adjustment",
        })

    historian_by_month: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in historian_rows:
        historian_by_month[row["timestamp_utc"][:7]].append(row)
    historian_files = []
    base_fields = [
        "record_id", "timestamp_utc", "facility_id", "line_id", "shift_id",
        "scheduled_minutes", "run_minutes", "ideal_cycle_minutes", "total_units",
        "good_units", "scrap_units", "energy_kwh", "record_type", "loaded_at_utc",
    ]
    for month, rows in sorted(historian_by_month.items()):
        fields = [field for field in base_fields if not (month <= "2025-03" and field == "energy_kwh")]
        path = DATA_ROOT / "raw" / "production-historian" / f"historian-{month}.csv"
        write_csv(path, rows, fields)
        historian_files.append(path)

    db_path = DATA_ROOT / "raw" / "maintenance-cmms" / "maintenance.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db_path)
    connection.executescript(
        """
        CREATE TABLE assets(asset_id TEXT PRIMARY KEY, line_id TEXT, asset_type TEXT, criticality TEXT);
        CREATE TABLE work_orders(work_order_id TEXT, revision INTEGER, asset_id TEXT, opened_utc TEXT, closed_utc TEXT, status TEXT, maintenance_type TEXT, is_reopened INTEGER, labor_hours REAL, parts_cost REAL);
        CREATE TABLE downtime_events(event_id TEXT PRIMARY KEY, work_order_id TEXT, asset_id TEXT, start_utc TEXT, end_utc TEXT, reason_code TEXT, planned INTEGER);
        """
    )
    connection.executemany("INSERT INTO assets VALUES(:asset_id,:line_id,:asset_type,:criticality)", assets)
    reason_codes = ["Mechanical", "Electrical", "Material Jam", "Changeover", "Controls", "Safety Check"]
    downtime_rows = []
    work_order_rows = []
    for number in range(1, 721):
        asset = rng.choice(assets)
        event_day = start + timedelta(days=rng.randrange((end - start).days + 1))
        start_hour = rng.randrange(24)
        duration_minutes = max(8, int(rng.lognormvariate(3.45, 0.55)))
        start_dt = datetime(event_day.year, event_day.month, event_day.day, start_hour, rng.randrange(60), tzinfo=UTC)
        end_dt = start_dt + timedelta(minutes=duration_minutes)
        work_order_id = f"WO-{number:06d}"
        status = "Closed" if number % 19 else "Reopened"
        work_order_rows.append((work_order_id, 1, asset["asset_id"], start_dt.isoformat(), end_dt.isoformat(), status, "Corrective" if number % 5 else "Preventive", int(status == "Reopened"), round(duration_minutes / 60 * rng.uniform(0.6, 1.4), 2), round(rng.uniform(25, 1400), 2)))
        if status == "Reopened":
            work_order_rows.append((work_order_id, 2, asset["asset_id"], start_dt.isoformat(), (end_dt + timedelta(hours=2)).isoformat(), "Closed", "Corrective", 1, round(duration_minutes / 60 * 1.6, 2), round(rng.uniform(800, 2600), 2)))
        downtime_rows.append((f"DTE-{number:06d}", work_order_id, asset["asset_id"], start_dt.isoformat(), end_dt.isoformat(), rng.choice(reason_codes), int(number % 5 == 0)))
    for orphan_number in range(1, config["maintenanceOrphans"] + 1):
        start_dt = datetime(2025, 12, orphan_number, 6, tzinfo=UTC)
        downtime_rows.append((f"DTE-ORPHAN-{orphan_number:02d}", f"WO-ORPHAN-{orphan_number:02d}", f"UNKNOWN-A{orphan_number}", start_dt.isoformat(), (start_dt + timedelta(minutes=45)).isoformat(), "Controls", 0))
    connection.executemany("INSERT INTO work_orders VALUES(?,?,?,?,?,?,?,?,?,?)", work_order_rows)
    connection.executemany("INSERT INTO downtime_events VALUES(?,?,?,?,?,?,?)", downtime_rows)
    connection.commit()
    connection.close()
    write_csv(DATA_ROOT / "raw" / "maintenance-cmms" / "assets-export.csv", [dict(row) for row in assets], ["asset_id", "line_id", "asset_type", "criticality"])
    write_csv(DATA_ROOT / "raw" / "maintenance-cmms" / "work-orders-export.csv", [
        dict(zip(["work_order_id", "revision", "asset_id", "opened_utc", "closed_utc", "status", "maintenance_type", "is_reopened", "labor_hours", "parts_cost"], row))
        for row in work_order_rows
    ], ["work_order_id", "revision", "asset_id", "opened_utc", "closed_utc", "status", "maintenance_type", "is_reopened", "labor_hours", "parts_cost"])
    write_csv(DATA_ROOT / "raw" / "maintenance-cmms" / "downtime-events-export.csv", [
        dict(zip(["event_id", "work_order_id", "asset_id", "start_utc", "end_utc", "reason_code", "planned"], row))
        for row in downtime_rows
    ], ["event_id", "work_order_id", "asset_id", "start_utc", "end_utc", "reason_code", "planned"])

    quality_path = DATA_ROOT / "raw" / "quality-qms" / "inspections.jsonl"
    quality_path.parent.mkdir(parents=True, exist_ok=True)
    defect_codes = ["DIM", "SUR", "MAT", "ASM", "ELEC", "PACK"]
    quality_rows = []
    inspection_count = 22000
    with quality_path.open("w", encoding="utf-8") as handle:
        for number in range(1, inspection_count + 1):
            line = rng.choice(lines)
            inspected_at = datetime.combine(start + timedelta(days=rng.randrange(365)), datetime.min.time(), tzinfo=UTC) + timedelta(hours=rng.randrange(24))
            inspected_units = rng.randint(18, 80)
            defect_units = max(0, int(rng.gauss(1.5, 1.8)))
            row = {
                "inspection_id": f"INS-{number:08d}",
                "inspected_at_utc": "invalid-date" if number <= 6 else inspected_at.isoformat().replace("+00:00", "Z"),
                "facility_id": line["facility_id"],
                "line_id": "" if 7 <= number <= 15 else line["line_id"],
                "material_id": rng.choice(materials)["material_id"],
                "inspected_units": inspected_units,
                "defect_units": min(inspected_units, defect_units),
                "defect_code": rng.choice(defect_codes) if defect_units else None,
                "disposition": "Rework" if defect_units else "Accepted",
            }
            quality_rows.append(row)
            handle.write(json.dumps(row, separators=(",", ":")) + "\n")

    inventory_rows = []
    snapshot_id = 0
    for week in range(52):
        snapshot_date = start + timedelta(days=week * 7)
        for facility in facilities:
            for material in materials:
                snapshot_id += 1
                demand = rng.uniform(18, 95)
                on_hand = max(0, int(rng.gauss(demand * rng.uniform(1.0, 3.4), demand * 0.55)))
                inventory_rows.append({
                    "snapshot_id": f"INV-{snapshot_id:08d}",
                    "snapshot_date": snapshot_date.isoformat(),
                    "facility_id": facility["id"],
                    "material_id": material["material_id"],
                    "on_hand_units": on_hand,
                    "open_order_units": rng.randint(0, 140),
                    "avg_daily_demand": round(demand / 7, 3),
                    "unit_cost": round(rng.uniform(1.2, 82), 2),
                })
    inventory_duplicate_indices = rng.sample(range(len(inventory_rows)), config["inventoryDuplicates"])
    inventory_rows.extend(dict(inventory_rows[index]) for index in inventory_duplicate_indices)
    write_csv(DATA_ROOT / "raw" / "inventory-erp" / "weekly-inventory.csv", inventory_rows, list(inventory_rows[0]))

    procurement_rows = []
    for number in range(1, 3601):
        supplier = rng.choice(suppliers)
        material = rng.choice(materials)
        order_date = start + timedelta(days=rng.randrange(340))
        promised_days = rng.randint(4, 35)
        actual_variance = int(rng.gauss(0.5, 4.2))
        ordered = rng.randint(25, 900)
        unit_price = rng.uniform(1.2, 82)
        baseline_price = unit_price * rng.uniform(0.93, 1.07)
        procurement_rows.append({
            "po_line_id": f"POL-{number:07d}",
            "order_date": order_date.isoformat(),
            "promised_date": (order_date + timedelta(days=promised_days)).isoformat(),
            "received_date": (order_date + timedelta(days=max(1, promised_days + actual_variance))).isoformat(),
            "supplier_id": supplier["supplier_id"],
            "material_id": material["material_id"],
            "facility_id": rng.choice(facilities)["id"],
            "ordered_units": ordered,
            "received_units": max(0, ordered - max(0, int(rng.gauss(4, 10)))),
            "unit_price": round(unit_price, 2),
            "baseline_price": round(baseline_price, 2),
            "defect_units": max(0, int(rng.gauss(ordered * 0.015, ordered * 0.012))),
        })
    for index in rng.sample(range(len(procurement_rows)), config["procurementDirtySupplierCodes"]):
        procurement_rows[index]["supplier_id"] = f" {procurement_rows[index]['supplier_id'].lower()} "
    write_csv(DATA_ROOT / "raw" / "procurement" / "purchase-order-lines.csv", procurement_rows, list(procurement_rows[0]))

    roster_rows = []
    for facility in facilities:
        for shift_number in range(1, 4):
            roster_rows.append({
                "team_id": f"{facility['id']}-T{shift_number}",
                "facility_id": facility["id"],
                "shift_id": f"S{shift_number}",
                "team_name": f"Synthetic Team {facility['id']}-{shift_number}",
                "manager_upn": f"manager.{facility['id'].lower()}.{shift_number}@example.com",
                "headcount": rng.randint(18, 34),
            })
    write_csv(DATA_ROOT / "raw" / "labor-roster" / "shift-roster.csv", roster_rows, list(roster_rows[0]))

    security_rows = [
        {"user_principal_name": "global.executive@example.com", "persona": "Global Executive", "facility_id": "*", "shift_id": "*"},
        {"user_principal_name": "north.leader@example.com", "persona": "Regional Leader", "facility_id": "F01", "shift_id": "*"},
        {"user_principal_name": "east.leader@example.com", "persona": "Regional Leader", "facility_id": "F02", "shift_id": "*"},
        {"user_principal_name": "central.manager@example.com", "persona": "Facility Manager", "facility_id": "F03", "shift_id": "*"},
        {"user_principal_name": "west.shift1@example.com", "persona": "Shift Manager", "facility_id": "F04", "shift_id": "S1"},
        {"user_principal_name": "west.shift2@example.com", "persona": "Shift Manager", "facility_id": "F04", "shift_id": "S2"},
        {"user_principal_name": "analyst@example.com", "persona": "Analyst", "facility_id": "F01", "shift_id": "S1"},
        {"user_principal_name": "restricted@example.com", "persona": "Restricted User", "facility_id": "F04", "shift_id": "S3"},
    ]
    write_csv(DATA_ROOT / "raw" / "security" / "user-access.csv", security_rows, list(security_rows[0]))

    blank_ids = {row["record_id"] for row in historian_rows if row["record_type"] == "Production" and row["good_units"] == ""}
    clean_production = []
    seen_ids = set()
    for row in historian_rows:
        if row["record_type"] != "Production" or row["record_id"] in seen_ids or row["record_id"] in blank_ids:
            continue
        seen_ids.add(row["record_id"])
        clean = dict(row)
        clean["facility_id"] = str(clean["facility_id"]).strip().upper()
        clean_production.append(clean)

    def summarize(rows: list[dict[str, Any]]) -> dict[str, float]:
        scheduled = sum(float(row["scheduled_minutes"]) for row in rows)
        run = sum(float(row["run_minutes"]) for row in rows)
        ideal_output = sum(float(row["run_minutes"]) / float(row["ideal_cycle_minutes"]) for row in rows)
        total = sum(int(row["total_units"]) for row in rows)
        good = sum(int(row["good_units"]) for row in rows)
        scrap = sum(int(row["scrap_units"]) for row in rows)
        availability = run / scheduled if scheduled else 0
        performance = total / ideal_output if ideal_output else 0
        quality = good / total if total else 0
        return {
            "scheduledMinutes": round_metric(scheduled, 3),
            "runMinutes": round_metric(run, 3),
            "goodUnits": good,
            "totalUnits": total,
            "scrapUnits": scrap,
            "availability": round_metric(availability),
            "performance": round_metric(performance),
            "quality": round_metric(quality),
            "oee": round_metric(availability * performance * quality),
            "scrapRate": round_metric(scrap / total if total else 0),
            "downtimeMinutes": round_metric(scheduled - run, 3),
        }

    overall = summarize(clean_production)
    monthly = []
    for month in sorted({row["timestamp_utc"][:7] for row in clean_production}):
        for facility in facilities:
            rows = [row for row in clean_production if row["timestamp_utc"].startswith(month) and row["facility_id"] == facility["id"]]
            monthly.append({"month": month, "facilityId": facility["id"], "facilityName": facility["name"], **summarize(rows)})

    downtime_pareto = Counter()
    for event in downtime_rows:
        start_dt = datetime.fromisoformat(event[3])
        end_dt = datetime.fromisoformat(event[4])
        downtime_pareto[event[5]] += (end_dt - start_dt).total_seconds() / 3600
    pareto = [{"reason": reason, "hours": round_metric(hours, 2)} for reason, hours in downtime_pareto.most_common()]

    latest_inventory = {}
    for row in inventory_rows:
        latest_inventory[(row["facility_id"], row["material_id"])] = row
    stockout_count = sum(1 for row in latest_inventory.values() if int(row["on_hand_units"]) == 0)
    low_supply_count = sum(1 for row in latest_inventory.values() if (int(row["on_hand_units"]) + int(row["open_order_units"])) / max(float(row["avg_daily_demand"]), 0.001) < 7)
    inventory_latest = [
        {
            "facilityId": row["facility_id"],
            "materialId": row["material_id"],
            "onHandUnits": int(row["on_hand_units"]),
            "openOrderUnits": int(row["open_order_units"]),
            "averageDailyDemand": float(row["avg_daily_demand"]),
            "daysSupply": round_metric((int(row["on_hand_units"]) + int(row["open_order_units"])) / max(float(row["avg_daily_demand"]), 0.001), 2),
        }
        for row in sorted(latest_inventory.values(), key=lambda item: (item["facility_id"], item["material_id"]))
    ]

    facility_summary = []
    for facility in facilities:
        rows = [row for row in clean_production if row["facility_id"] == facility["id"]]
        facility_summary.append({"facilityId": facility["id"], "facilityName": facility["name"], **summarize(rows)})

    supplier_summary = []
    for supplier in suppliers:
        rows = [row for row in procurement_rows if str(row["supplier_id"]).strip().upper() == supplier["supplier_id"]]
        ordered = sum(int(row["ordered_units"]) for row in rows)
        defects = sum(int(row["defect_units"]) for row in rows)
        on_time = sum(1 for row in rows if row["received_date"] <= row["promised_date"])
        actual_cost = sum(int(row["received_units"]) * float(row["unit_price"]) for row in rows)
        baseline_cost = sum(int(row["received_units"]) * float(row["baseline_price"]) for row in rows)
        supplier_summary.append({
            "supplierId": supplier["supplier_id"],
            "supplierName": supplier["supplier_name"],
            "onTimeRate": round_metric(on_time / len(rows) if rows else 0),
            "defectRate": round_metric(defects / ordered if ordered else 0),
            "purchasePriceVariance": round_metric(actual_cost - baseline_cost, 2),
        })

    persona_totals = []
    for access in security_rows:
        rows = clean_production
        if access["facility_id"] != "*":
            rows = [row for row in rows if row["facility_id"] == access["facility_id"]]
        if access["shift_id"] != "*":
            rows = [row for row in rows if row["shift_id"] == access["shift_id"]]
        persona_totals.append({
            "userPrincipalName": access["user_principal_name"],
            "persona": access["persona"],
            "visibleRows": len(rows),
            "goodUnits": summarize(rows)["goodUnits"],
            "oee": summarize(rows)["oee"],
        })

    web_aggregates = {
        "project": config["project"],
        "generatorVersion": config["generatorVersion"],
        "seed": config["seed"],
        "dateRange": {"start": config["dateStart"], "end": config["dateEnd"]},
        "kpis": overall,
        "monthlyFacility": monthly,
        "facilitySummary": facility_summary,
        "downtimePareto": pareto,
        "inventoryRisk": {"stockoutMaterials": stockout_count, "lowSupplyMaterials": low_supply_count, "materialFacilityPairs": len(latest_inventory)},
        "inventoryLatest": inventory_latest,
        "supplierSummary": supplier_summary,
        "facilityTopology": [{**facility, "lines": [line for line in lines if line["facility_id"] == facility["id"]]} for facility in facilities],
        "securityPersonas": persona_totals,
    }
    write_json(DATA_ROOT / "web-aggregates" / "factory-intelligence.json", web_aggregates)

    expected = {
        "generatorVersion": config["generatorVersion"],
        "seed": config["seed"],
        "configHash": config_hash,
        "rowCounts": {
            "historianRaw": len(historian_rows),
            "factProductionExpected": len(clean_production),
            "maintenanceWorkOrderRevisions": len(work_order_rows),
            "downtimeEventsRaw": len(downtime_rows),
            "qualityInspectionsRaw": len(quality_rows),
            "inventorySnapshotsRaw": len(inventory_rows),
            "procurementLinesRaw": len(procurement_rows),
            "securityMappings": len(security_rows),
        },
        "defects": {
            "historianDuplicateRows": config["historianDuplicateRows"],
            "historianMissingGoodUnits": config["historianMissingGoodUnits"],
            "historianDirtyFacilityCodes": config["historianDirtyFacilityCodes"],
            "historianAdjustmentRows": config["historianAdjustments"],
            "maintenanceOrphanAssets": config["maintenanceOrphans"],
            "qualityInvalidDates": 6,
            "qualityBlankLineIds": 9,
            "inventoryDuplicateRows": config["inventoryDuplicates"],
            "procurementDirtySupplierCodes": config["procurementDirtySupplierCodes"],
        },
        "baselineKpis": overall,
        "monthlyFacility": monthly,
        "downtimePareto": pareto,
        "securityPersonaTotals": persona_totals,
        "webAggregateControlHash": sha256_text(stable_json(web_aggregates)),
    }
    write_json(DATA_ROOT / "expected-results" / "expected-results.json", expected)
    write_json(DATA_ROOT / "rejected" / "expected-rejections.json", {
        "factProduction": {"missingGoodUnits": sorted(blank_ids)},
        "factQuality": {"invalidDates": [row["inspection_id"] for row in quality_rows if row["inspected_at_utc"] == "invalid-date"], "blankLineIds": [row["inspection_id"] for row in quality_rows if not row["line_id"]]},
        "factDowntime": {"orphanAssets": [row[0] for row in downtime_rows if str(row[2]).startswith("UNKNOWN-")]},
    })

    source_descriptions = [
        ("Production Historian", "CSV folder", "raw/production-historian", "One row per line-hour reading", "record_id", len(historian_rows), ["stg_Historian", "FactProduction"]),
        ("Maintenance CMMS", "SQLite", "raw/maintenance-cmms/maintenance.db", "Work-order revision and downtime event", "work_order_id / event_id", len(work_order_rows) + len(downtime_rows), ["stg_WorkOrders", "FactDowntime", "DimAsset"]),
        ("Quality QMS", "JSON Lines", "raw/quality-qms/inspections.jsonl", "One inspection event", "inspection_id", len(quality_rows), ["stg_Quality", "FactQuality"]),
        ("Inventory ERP", "CSV", "raw/inventory-erp/weekly-inventory.csv", "Material-facility-week snapshot", "snapshot_id", len(inventory_rows), ["stg_Inventory", "FactInventorySnapshot"]),
        ("Procurement", "CSV", "raw/procurement/purchase-order-lines.csv", "Purchase order line", "po_line_id", len(procurement_rows), ["stg_Procurement", "FactProcurement"]),
        ("Supplier Master", "JSON", "raw/supplier-master/suppliers.json", "Supplier", "supplier_id", len(suppliers), ["DimSupplier"]),
        ("Labor Roster", "CSV", "raw/labor-roster/shift-roster.csv", "Facility-shift team", "team_id", len(roster_rows), ["DimShift"]),
        ("Security Access", "CSV", "raw/security/user-access.csv", "User-facility-shift access mapping", "user_principal_name + facility_id + shift_id", len(security_rows), ["BridgeUserAccess"]),
    ]
    source_manifest = {
        "project": config["project"],
        "generatorVersion": config["generatorVersion"],
        "seed": config["seed"],
        "configHash": config_hash,
        "sources": [
            {
                "sourceName": name,
                "description": f"Independent fictional {name} source.",
                "format": fmt,
                "relativeLocation": location,
                "grain": grain,
                "primaryIdentifier": key,
                "expectedRowCount": count,
                "dateRange": {"start": config["dateStart"], "end": config["dateEnd"]},
                "simulatedRefreshCadence": "Daily" if name not in {"Inventory ERP", "Labor Roster"} else "Weekly",
                "knownDataQualityDefects": "See DATA_QUALITY_ISSUES.md and expected-results.json.",
                "consumingQueries": queries,
                "producedTables": [query for query in queries if query.startswith("Fact") or query.startswith("Dim") or query.startswith("Bridge")],
                "required": True,
                "generatorVersion": config["generatorVersion"],
                "generatorSeed": config["seed"],
            }
            for name, fmt, location, grain, key, count, queries in source_descriptions
        ],
    }
    write_json(DATA_ROOT / "config" / "source-manifest.json", source_manifest)

    business_files = sorted(
        path for folder in [DATA_ROOT / "raw", DATA_ROOT / "reference", DATA_ROOT / "expected-results", DATA_ROOT / "web-aggregates", DATA_ROOT / "rejected"]
        for path in folder.rglob("*") if path.is_file()
    )
    file_manifest = [
        {"path": path.relative_to(DATA_ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in business_files
    ]
    generation_manifest = {
        "project": config["project"],
        "generatorVersion": config["generatorVersion"],
        "seed": config["seed"],
        "configHash": config_hash,
        "generatedAtUtc": datetime.now(UTC).isoformat(),
        "dateRange": {"start": config["dateStart"], "end": config["dateEnd"]},
        "files": file_manifest,
        "defectsInjected": expected["defects"],
        "expectedControlTotals": overall,
        "validationStatus": "pending-independent-validation",
        "warnings": ["Power BI Desktop refresh and DAX execution are not part of generation."],
        "businessContentHash": sha256_text(stable_json(file_manifest)),
    }
    write_json(DATA_ROOT / "generated-manifests" / "generation-manifest.json", generation_manifest)

    website_target = REPO_ROOT / "apps" / "portfolio-web" / "src" / "data" / "factory-intelligence.json"
    write_json(website_target, web_aggregates)
    print(json.dumps({"status": "generated", "businessContentHash": generation_manifest["businessContentHash"], "factProductionRows": len(clean_production), "rawHistorianRows": len(historian_rows)}, indent=2))


if __name__ == "__main__":
    main()
