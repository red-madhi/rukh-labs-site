# Business scenario

## Decision

Operations leaders need one governed system to decide where lost productive capacity originates, whether reliability or quality is the primary constraint, and which inventory or supplier risks can disrupt the next production window.

## Users

- Global executives compare system health and trends.
- Regional and facility leaders isolate local loss drivers.
- Shift managers see only their authorized team slice.
- Reliability engineers rank failure modes and asset exposure.
- Quality leaders connect defects to facility, line, and material.
- Supply-chain analysts evaluate inventory buffers, delivery performance, defects, and price variance.

## Decisions supported

1. Prioritize the facility, line, shift, asset, or cause with the largest avoidable capacity loss.
2. Separate availability, performance, and quality contributions to OEE.
3. Set a defensible inventory buffer and identify exposed material-facility pairs.
4. Segment suppliers by service, defect, and cost outcomes.
5. Verify that dynamic security changes the visible row population and KPI totals.

The analysis period is calendar year 2025. All data and findings are synthetic portfolio evidence, not claims about a real organization.

