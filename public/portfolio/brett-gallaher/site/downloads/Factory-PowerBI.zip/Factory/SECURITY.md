# Security

The role `Dynamic Facility and Shift Access` resolves a lowercase `USERPRINCIPALNAME()` against `BridgeUserAccess`, filters `DimFacility`, and applies an optional shift constraint through `DimShift`. All test identities use the reserved `example.com` domain.

Required Desktop tests:

1. Global Executive sees 105,090 rows and 82.3296% OEE.
2. North Regional Leader sees 26,273 rows and 83.1088% OEE.
3. Central Facility Manager sees 26,272 rows and 87.0977% OEE.
4. West Shift 1 Manager sees 8,756 rows and 81.3619% OEE.
5. An unknown identity sees no authorized facilities.

The web demo simulates these personas using pre-aggregated synthetic totals and labels the behavior as a simulation. It is not an authentication system.

