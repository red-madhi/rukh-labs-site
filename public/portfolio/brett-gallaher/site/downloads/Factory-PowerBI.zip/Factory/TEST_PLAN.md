# Test plan

## Automated here

- Regenerate twice and compare business-content hash.
- Recover every injected defect count.
- Reconcile clean production row count and KPI controls.
- Parse every JSON/PBIR artifact and run Microsoft's PBIR authoring validator.
- Validate page/visual counts, bindings, navigation, project metadata, and download targets.
- Build, type-check, lint, and privacy-scan the website.
- Scan packaged archives after creation.

## Required in Power BI Desktop

- Open PBIP, set `pDataRoot`, and refresh without errors.
- Confirm relationship cardinality, active/inactive date roles, and no ambiguity.
- Execute control DAX by facility and month against `expected-results.json`.
- Test every RLS persona and an unknown user.
- Confirm the local full refresh completes and all production rows fall inside the configured date window.
- Test slicers, cross-filter interactions, drillthrough, tooltips, bookmarks, page navigation, and Reset Filters.
- Inspect standard and phone layouts; check browser/device screenshots where applicable.
- Run Performance Analyzer and capture slow visuals.
- Save Desktop-validated PBIX/PBIT only after all checks pass.
