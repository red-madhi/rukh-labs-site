# Power Query

Every import partition contains its complete M expression in the corresponding TMDL table file under `report/FactoryIntelligence.SemanticModel/definition/tables/`.

The query layer demonstrates:

- folder ingestion and monthly-schema combination;
- schema-drift handling with `Table.HasColumns`;
- explicit culture-aware type enforcement;
- trim/case normalization of business keys;
- revision-aware deduplication;
- parse-safe JSON Lines processing;
- orphan rejection through master-data joins;
- relative-path parameterization through `pDataRoot`;
- `RangeStart`/`RangeEnd` filtering for incremental production refresh.

This local workspace copy defaults `pDataRoot` to a neutral local fixture-data copy. If it is moved or extracted elsewhere, set `pDataRoot` to that copy's `data` folder before refreshing.
