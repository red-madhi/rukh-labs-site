# Website mapping

The web-native demo consumes `apps/portfolio-web/src/data/factory-intelligence.json`, copied from the generator's `data/web-aggregates` output. The website never embeds a Power BI report and never invents an independent KPI total.

| Web interaction | Semantic-model analogue |
|---|---|
| Facility filter | DimFacility slicer |
| Metric switcher | Metric Selector + Selected Metric Value |
| Monthly trend | DimDate Month + selected measure |
| Downtime ranking | Reason Code + Downtime Hours |
| Inventory buffer slider | Inventory Buffer Days + Inventory Units at Risk |
| Supplier quadrant | Supplier OTD vs Supplier Defect Rate |
| Security persona | Dynamic RLS test identity |
| Model/DAX/M explorer | TMDL source catalog |

The demo is an explanatory analytical replica over safe aggregates. The `.pbip` project and synthetic data package remain the executable BI deliverables.

