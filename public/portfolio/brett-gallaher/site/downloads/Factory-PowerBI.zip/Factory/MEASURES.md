# Measures

All report values use explicit measures under `_Measures`; implicit aggregation is not used in authored visuals.

Core formulas:

```DAX
Availability = DIVIDE([Run Minutes], [Scheduled Minutes])
Performance = DIVIDE([Total Units], [Ideal Output Units])
Quality Rate = DIVIDE([Good Units], [Total Units])
OEE = [Availability] * [Performance] * [Quality Rate]
MTBF = DIVIDE([Run Minutes], [Unplanned Failure Count], 0)
MTTR = DIVIDE(CALCULATE([Downtime Minutes], FactDowntime[Is Planned] = FALSE()), [Unplanned Failure Count], 0)
```

The model also includes throughput, scrap, FPY, defect/rework, schedule attainment, inventory days supply, buffer-risk units, stockout rate, supplier on-time delivery, supplier defect rate, purchase-price variance, rolling 28-day OEE, prior-period comparisons, dynamic metric value/title, and security diagnostic measures. Full definitions and display folders are in `_Measures.tmdl`.

