# Visual design and chart map

The report uses a graphite canvas with high-contrast ink, a lime primary series, cobalt comparator, amber risk state, direct labels, and non-color cues. It echoes Rukh Labs' dark, technical confidence while avoiding its red/bronze identity, typography, content, and exact composition.

| Page | Analytical question | Primary visual | Fields / measures | Supported takeaway |
|---|---|---|---|---|
| Factory Pulse | Is the system healthy and where is the gap? | KPI strip + 12-month line | OEE components by month | Status and movement |
| Production Flow | Which facility constrains output? | Ranked bars + trend | good units, throughput, facility | Comparative flow |
| Asset Reliability | Which assets fail most severely? | Scatter + table | MTBF, MTTR, downtime | Reliability segmentation |
| Downtime Pareto | Which causes dominate loss? | Sorted bar / Pareto | downtime hours, reason | Concentration of loss |
| Quality Control | Where is quality loss concentrated? | Trend + ranked bars | defect rate, FPY, code | Defect movement and rank |
| Maintenance Timeline | When do incidents cluster? | Date trend + event table | downtime, planned status | Temporal pattern |
| Inventory Risk | What changes with buffer policy? | What-if cards + risk table | days supply, units at risk | Scenario exposure |
| Procurement | Are receipts late or expensive? | KPI + variance bars | OTD, PPV, volume | Service/cost trade-off |
| Supplier Performance | Which suppliers combine risk dimensions? | Scatter | OTD, defect rate, volume | Supplier segmentation |
| Root Cause Explorer | Where should investigation start? | Decomposition-style bars | facility, line, cause | Guided isolation |
| Production Detail | Which exact records explain the view? | Detail table | timestamp, facility, line, units | Auditability |
| Model Architecture | How is the system governed? | Topology + diagnostics | source/table relationships | Technical transparency |

Bars start at zero; scatter keeps one observation grain; trends expose twelve monthly points. Titles are descriptive, subtitles state units/date/source, and color is never the only distinction.

