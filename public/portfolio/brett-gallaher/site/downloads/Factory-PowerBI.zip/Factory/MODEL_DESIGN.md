# Model design

The model uses separate facts at their natural grains, conformed dimensions, single-direction many-to-one relationships, hidden technical keys, and explicit measures. It avoids fact-to-fact relationships and bi-directional filtering.

FactProduction joins directly to date, facility, line, and a facility-shift team key. Other facts join only to dimensions relevant to their grain. Procurement carries two date roles: active order date and inactive receipt date. The user-access bridge is not used as a general filter path; role expressions resolve authorized facilities/shifts from `USERPRINCIPALNAME()`.

The production query includes `RangeStart`/`RangeEnd` filters and uses a direct local full-refresh path for reliable fixture loading in Power BI Desktop. The date window remains in place for later deployment-specific incremental-refresh configuration.

Calculation groups supply Current, MTD, YTD, Prior Month, and Variance to Prior Month behaviors. Disconnected selectors drive metric switching and inventory what-if analysis without changing the physical model.
