# Synthetic source systems

The CSV files under `data/raw/portable-fixtures` mirror the independent fictional business entities embedded in the portable semantic model. No employer, client, or personal data is included.
