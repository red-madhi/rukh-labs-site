# Visual design

Atlas editorial system: lavender rail, compact market controls, wide analytical canvas, cost-risk bubbles, and role readiness matrices.
