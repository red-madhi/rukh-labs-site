# Power Query M catalog

Imported tables use deterministic typed inline M fixtures, including a generated calendar built with `List.Dates`. Text dimensions are normalized with `Table.TransformColumns`, and every imported column is enforced with `Table.TransformColumnTypes`. This keeps the public project fully portable while exposing the complete M expressions in TMDL.
