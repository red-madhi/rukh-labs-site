# Business scenario

Compare fictional market demand, internal readiness, mobility cost, external hiring cost, retention risk, and assignment outcomes before committing workforce budget.
