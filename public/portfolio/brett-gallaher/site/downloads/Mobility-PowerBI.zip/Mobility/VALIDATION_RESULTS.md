# Validation results

- PBIR/TMDL: schemas generated and deserialized successfully
- Power Query M: all partitions parsed successfully by the installed Power BI M parser
- Power BI Desktop: open, full refresh, DAX query, save, and clean reopen verified in version 2.156.951.0
- Privacy: synthetic fixtures only
