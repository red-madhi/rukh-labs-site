# Data dictionary

- **DimMarket**: Fictional workforce markets and planning maturity.
- **DimRole**: Fictional role families used for demand and readiness planning.
- **FactMobilityPlan**: Monthly demand, ready supply, cost, risk, and outcome planning grain.
- **Scenario Posture**: Disconnected scenario parameter for demand sensitivity.
