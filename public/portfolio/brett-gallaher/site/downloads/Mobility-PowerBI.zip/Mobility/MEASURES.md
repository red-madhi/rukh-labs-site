# DAX measure catalog

## Demand Roles
Business folder: Demand

```DAX
SUM(FactMobilityPlan[Demand Roles])
```

## Ready Talent
Business folder: Supply

```DAX
SUM(FactMobilityPlan[Ready Talent])
```

## Demand Gap
Business folder: Demand

```DAX
MAX(0, [Demand Roles] - [Ready Talent])
```

## Readiness Rate
Business folder: Supply

```DAX
DIVIDE([Ready Talent], [Demand Roles])
```

## Scenario Cost
Business folder: Cost

```DAX
SUM(FactMobilityPlan[Mobility Cost]) + SUM(FactMobilityPlan[External Hire Cost])
```

## Retention Risk
Business folder: Risk

```DAX
DIVIDE(SUMX(FactMobilityPlan, FactMobilityPlan[Retention Risk] * FactMobilityPlan[Demand Roles]), [Demand Roles])
```

## Assignment Success
Business folder: Outcomes

```DAX
DIVIDE(SUMX(FactMobilityPlan, FactMobilityPlan[Assignment Success] * FactMobilityPlan[Ready Talent]), [Ready Talent])
```

## Internal Fill Rate
Business folder: Outcomes

```DAX
DIVIDE([Ready Talent], [Demand Roles])
```

## Adjusted Demand
Business folder: Scenario

```DAX
[Demand Roles] * SELECTEDVALUE('Scenario Posture'[Demand Multiplier], 1)
```

## Adjusted Gap
Business folder: Scenario

```DAX
MAX(0, [Adjusted Demand] - [Ready Talent])
```

## Mobility Cost
Business folder: Cost

```DAX
SUM(FactMobilityPlan[Mobility Cost])
```

## External Hire Cost
Business folder: Cost

```DAX
SUM(FactMobilityPlan[External Hire Cost])
```

## Decision Signal
Business folder: Narrative

```DAX
"MOBILIZE FIRST  •  " & FORMAT([Readiness Rate], "0.0%") & " of demand is internally ready  •  protect high-risk cohorts"
```
