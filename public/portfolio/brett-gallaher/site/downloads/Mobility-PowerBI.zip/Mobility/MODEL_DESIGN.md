# Model design

A conformed calendar filters monthly planning facts. Market and role dimensions remain independent, while the disconnected Scenario Posture table changes adjusted demand without contaminating the base facts.
