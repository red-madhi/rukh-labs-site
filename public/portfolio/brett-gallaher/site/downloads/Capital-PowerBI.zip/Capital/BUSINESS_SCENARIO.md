# Business scenario

Govern a fictional infrastructure portfolio across approved budgets, actuals, forecasts, contingency, risks, project stages, and delivery progress.
