# Capital Portfolio Scenario Studio

Synthetic portfolio project inspired by common industry challenges and professional experience. It does not reproduce an employer or client report, dataset, system, or proprietary business process.

## Open the report

Extract the complete project folder, then open `report/CapitalPortfolioStudio.pbip` in Power BI Desktop. The semantic model uses portable embedded synthetic fixture tables, so the report refreshes without personal file paths or credentials.

## Technical focus

- Schema: Intentional snowflake with monthly portfolio snapshots
- Independent synthetic fixture tables: 4
- Explicit DAX measures: 13
- Report pages: 3
- Power Query M: typed inline fixtures, text normalization, deterministic refresh
- Validation: PBIR schema validation plus Power BI Desktop open/refresh verification
