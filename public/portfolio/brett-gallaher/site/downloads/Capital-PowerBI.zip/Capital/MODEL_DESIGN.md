# Model design

Project attributes snowflake to Program so portfolio leaders can analyze program rollups without duplicating program metadata. A disconnected funding scenario changes capital posture while preserving approved baselines.
