# DAX measure catalog

## Portfolio Budget
Business folder: Financial

```DAX
SUM(FactPortfolioSnapshot[Budget])
```

## Actual Cost
Business folder: Financial

```DAX
SUM(FactPortfolioSnapshot[Actual Cost])
```

## Forecast Cost
Business folder: Financial

```DAX
SUM(FactPortfolioSnapshot[Forecast Cost])
```

## Forecast Variance
Business folder: Financial

```DAX
[Forecast Cost] - [Portfolio Budget]
```

## Forecast Variance %
Business folder: Financial

```DAX
DIVIDE([Forecast Variance], [Portfolio Budget])
```

## Risk Exposure
Business folder: Risk

```DAX
SUM(FactPortfolioSnapshot[Risk Exposure])
```

## Contingency
Business folder: Risk

```DAX
SUM(FactPortfolioSnapshot[Contingency])
```

## Schedule Performance
Business folder: Delivery

```DAX
DIVIDE(SUM(FactPortfolioSnapshot[Actual Progress]), SUM(FactPortfolioSnapshot[Planned Progress]))
```

## Risk Adjusted NPV
Business folder: Value

```DAX
SUM(FactPortfolioSnapshot[Net Present Value]) - [Risk Exposure]
```

## Late Projects
Business folder: Delivery

```DAX
COUNTROWS(FILTER(VALUES(DimProject[Project ID]), CALCULATE(AVERAGE(FactPortfolioSnapshot[Actual Progress])) < CALCULATE(AVERAGE(FactPortfolioSnapshot[Planned Progress])) - 0.03))
```

## Scenario Funding
Business folder: Scenario

```DAX
[Portfolio Budget] * SELECTEDVALUE('Funding Scenario'[Funding Multiplier], 1)
```

## Funding Gap
Business folder: Scenario

```DAX
[Forecast Cost] - [Scenario Funding]
```

## Decision Signal
Business folder: Narrative

```DAX
"FUND VALUE, NOT MOMENTUM  •  " & FORMAT([Risk Adjusted NPV], "$0.0,,M") & " risk-adjusted NPV  •  " & FORMAT([Late Projects], "0") & " projects need a stage-gate review"
```
