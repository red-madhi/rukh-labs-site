# Data dictionary

- **DimProgram**: Fictional infrastructure programs and portfolio groupings.
- **DimProject**: Fictional capital projects with stage and priority attributes.
- **FactPortfolioSnapshot**: Monthly project-level financial, risk, and delivery snapshots.
- **Funding Scenario**: Disconnected funding posture used for portfolio what-if analysis.
