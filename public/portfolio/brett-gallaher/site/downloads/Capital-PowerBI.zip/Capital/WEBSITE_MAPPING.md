# Website mapping

The web dashboard at `/work/capital-portfolio-scenario-studio` uses the same business question, metric definitions, categories, and decision narrative. The website is a responsive manifestation rather than a literal copy of the Desktop canvas.
