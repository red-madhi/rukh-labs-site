# Data dictionary

- **DimQueue**: Fictional service queues and operating groups.
- **DimChannel**: Voice, chat, and email interaction channels.
- **FactServiceInterval**: Monthly aggregate of the portable 30-minute service interval model.
- **Metric Selector**: Disconnected selector for the diagnostic axis.
