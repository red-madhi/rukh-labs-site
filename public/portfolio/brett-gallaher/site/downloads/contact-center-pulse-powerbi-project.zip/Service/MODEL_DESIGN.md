# Model design

Queue and Channel filter a portable service-interval fact. Weighted service and QA measures preserve the correct denominator. A disconnected metric table drives the workbench axis through SWITCH and SELECTEDVALUE.
