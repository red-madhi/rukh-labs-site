# Business scenario

Balance fictional multi-channel demand, service level, staffing, quality, customer experience, and cost without hiding queue-level tradeoffs.
