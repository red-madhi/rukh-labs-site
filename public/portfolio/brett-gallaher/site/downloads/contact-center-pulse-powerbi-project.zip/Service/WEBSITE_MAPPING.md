# Website mapping

The web dashboard at `/work/contact-center-pulse` uses the same business question, metric definitions, categories, and decision narrative. The website is a responsive manifestation rather than a literal copy of the Desktop canvas.
