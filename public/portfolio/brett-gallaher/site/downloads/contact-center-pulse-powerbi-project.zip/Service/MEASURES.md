# DAX measure catalog

## Offered Contacts
Business folder: Demand

```DAX
SUM(FactServiceInterval[Offered Contacts])
```

## Answered Contacts
Business folder: Demand

```DAX
SUM(FactServiceInterval[Answered Contacts])
```

## Service Level
Business folder: Service

```DAX
DIVIDE(SUM(FactServiceInterval[Within SLA]), [Answered Contacts])
```

## Abandon Rate
Business folder: Service

```DAX
DIVIDE(SUM(FactServiceInterval[Abandoned Contacts]), [Offered Contacts])
```

## Average Handle Time
Business folder: Efficiency

```DAX
DIVIDE(SUM(FactServiceInterval[Handle Seconds]), [Answered Contacts])
```

## Occupancy
Business folder: Staffing

```DAX
DIVIDE(SUM(FactServiceInterval[Handle Seconds]), SUM(FactServiceInterval[Staffed Seconds]))
```

## Schedule Adherence
Business folder: Staffing

```DAX
DIVIDE(SUM(FactServiceInterval[Staffed Seconds]), SUM(FactServiceInterval[Scheduled Seconds]))
```

## QA Score
Business folder: Quality

```DAX
DIVIDE(SUMX(FactServiceInterval, FactServiceInterval[QA Score] * FactServiceInterval[Answered Contacts]), [Answered Contacts])
```

## Service Cost
Business folder: Cost

```DAX
SUM(FactServiceInterval[Service Cost])
```

## Cost per Contact
Business folder: Cost

```DAX
DIVIDE([Service Cost], [Answered Contacts])
```

## Staffing Gap
Business folder: Staffing

```DAX
DIVIDE(SUM(FactServiceInterval[Scheduled Seconds]) - SUM(FactServiceInterval[Staffed Seconds]), 3600)
```

## Selected Metric
Business folder: Dynamic

```DAX
SWITCH(SELECTEDVALUE('Metric Selector'[Metric], "Service level"), "Abandon rate", [Abandon Rate], "Occupancy", [Occupancy], "QA score", [QA Score], [Service Level])
```

## Decision Signal
Business folder: Narrative

```DAX
"STAFF THE INTERVAL, NOT THE AVERAGE  •  service level " & FORMAT([Service Level], "0.0%") & "  •  move cross-trained capacity toward the highest staffing gap"
```
