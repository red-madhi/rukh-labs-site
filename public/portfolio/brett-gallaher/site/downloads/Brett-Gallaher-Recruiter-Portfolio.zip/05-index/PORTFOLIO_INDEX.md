# Brett Gallaher — Recruiter Portfolio Technical Index

This pack contains four completed analytics products. Each product has two manifestations: a Power BI Desktop project for offline inspection and an interactive web experience for immediate review.

## Start here

1. Open `01-resume/Brett-Gallaher-Redacted-Resume.pdf`.
2. Scan `03-report-images` and `04-report-videos`.
3. Extract any short-named project in `02-PBI` and open its `.pbip` file.
4. Compare the Desktop model with the matching web route listed below.

## Paired products

### Global Workforce Mobility Strategy Lab

- Desktop artifact: `MobilityStrategyLab.pbip`
- Website route: `/work/global-workforce-mobility-strategy-lab`
- Model: Star schema with a disconnected demand scenario
- Technical proof: Weighted readiness, demand gap, scenario economics, retention exposure, and assignment outcomes.

### Capital Portfolio Scenario Studio

- Desktop artifact: `CapitalPortfolioStudio.pbip`
- Website route: `/work/capital-portfolio-scenario-studio`
- Model: Program-project snowflake with a disconnected funding scenario
- Technical proof: Risk-adjusted NPV, forecast variance, schedule performance, contingency, and stage-gate prioritization.

### Factory Intelligence System

- Desktop artifact: `FactoryIntelligence.pbip`
- Website route: `/work/factory-intelligence-system`
- Model: High-volume multi-fact manufacturing star
- Technical proof: Explicit OEE, governed production facts, quality controls, capacity-loss analysis, dynamic RLS, and PBIR source.

### Contact Center Pulse

- Desktop artifact: `ContactCenterPulse.pbip`
- Website route: `/work/contact-center-pulse`
- Model: Service star with a disconnected dynamic metric selector
- Technical proof: Weighted service and QA measures, staffing diagnostics, queue economics, and a SWITCH-driven metric workbench.

## Portability and privacy

- All public data is synthetic.
- The three new models use typed inline Power Query M fixtures so they do not depend on a personal absolute file path.
- The factory project includes its generated synthetic source environment and relative portable model configuration.
- The public résumé contains no phone number, address, or company names. Request the unredacted copy at rdmdhq@gmail.com.

## Demonstrated Power BI competency

PBIP/PBIR source control, TMDL semantic models, DAX measure design, weighted measures, filter context, what-if scenarios, dynamic axes, Power Query M typing and normalization, star and snowflake schemas, RLS/OLS patterns, high-volume operational modeling, visual design systems, accessibility, and executive storytelling.
